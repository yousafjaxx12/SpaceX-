import pandas as pd
from dash import Dash, dcc, html, Input, Output
import plotly.express as px

df = pd.read_csv("../data/spacex_cleaned.csv")

app = Dash(__name__)
app.layout = html.Div([
    html.H1("SpaceX Launch Success Dashboard"),
    dcc.Dropdown(
        id="site",
        options=[{"label": x, "value": x} for x in sorted(df["launch_site"].dropna().unique())],
        placeholder="Select a launch site"
    ),
    dcc.RangeSlider(
        id="payload",
        min=float(df["payload_mass_kg"].min()),
        max=float(df["payload_mass_kg"].max()),
        value=[float(df["payload_mass_kg"].min()), float(df["payload_mass_kg"].max())],
        tooltip={"placement":"bottom","always_visible":False}
    ),
    dcc.Graph(id="scatter"),
    dcc.Graph(id="success_pie")
])

@app.callback(
    Output("scatter","figure"),
    Output("success_pie","figure"),
    Input("site","value"),
    Input("payload","value")
)
def update(site, payload):
    d = df[(df["payload_mass_kg"] >= payload[0]) & (df["payload_mass_kg"] <= payload[1])].copy()
    if site:
        d = d[d["launch_site"] == site]

    scatter = px.scatter(
        d, x="payload_mass_kg", y="success",
        color="launch_site", hover_data=["name","rocket"],
        title="Payload vs Launch Outcome"
    )

    ratio = d.groupby("launch_site")["success"].mean().reset_index()
    pie = px.pie(ratio, names="launch_site", values="success",
                 title="Launch Success Ratio")
    return scatter, pie

if __name__ == "__main__":
    app.run(debug=True)
