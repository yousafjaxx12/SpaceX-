# SpaceX Data Science Capstone

This repository contains the notebooks and Python files for the SpaceX Data Science Capstone.

## Notebooks

1. `01_SpaceX_API_Data_Collection.ipynb` – REST API collection
2. `02_Web_Scraping.ipynb` – Wikipedia table collection
3. `03_Data_Wrangling.ipynb` – cleaning and feature preparation
4. `04_EDA_Visualization.ipynb` – required EDA charts
5. `05_EDA_SQL.ipynb` – SQL analysis
6. `06_Folium_Map.ipynb` – interactive maps
7. `07_Predictive_Analysis_Classification.ipynb` – classification models
8. `08_Plotly_Dash_Preparation.ipynb` – dashboard figures/preparation

## Python application

`python/dashboard.py` is a starter Plotly Dash dashboard.

## Important

Run the notebooks in order. The API and scraping notebooks require internet access. The SQL notebook contains the required SQL questions, but the exact Coursera SQL lab questions involving `landing_outcome` require the course-provided dataset containing that column. Do not claim exact results for missing fields.

## Suggested GitHub submission

After running the notebooks successfully, commit both the `.ipynb` files and generated data/output files that are permitted by your course.
